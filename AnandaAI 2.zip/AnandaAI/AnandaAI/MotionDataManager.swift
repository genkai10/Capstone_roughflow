//
//  MotionDataManager.swift
//  AnandaAI
//
//  Created by Dharini Mrug on 02/11/24.
//

import Foundation
import CoreMotion

class MotionDataManager: ObservableObject {
    private var motionManager = CMMotionManager()
    @Published var accelerometerData: CMAccelerometerData?

    func startAccelerometerUpdates() {
        guard motionManager.isAccelerometerAvailable else { return }
        motionManager.accelerometerUpdateInterval = 1.0 / 60.0
        motionManager.startAccelerometerUpdates(to: .main) { data, error in
            if let data = data {
                DispatchQueue.main.async {
                    self.accelerometerData = data
                }
            }
        }
    }

    func stopAccelerometerUpdates() {
        motionManager.stopAccelerometerUpdates()
    }
}

