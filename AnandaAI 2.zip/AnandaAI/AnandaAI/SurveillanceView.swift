//
//  SurveillanceView.swift
//  AnandaAI
//
//  Created by Diya Maria on 24/09/24.
//
import SwiftUI
import WebKit

// Step 1: Create a UIViewRepresentable to embed WKWebView in SwiftUI
struct WebView: UIViewRepresentable {
    let url: URL

    func makeUIView(context: Context) -> WKWebView {
        return WKWebView()
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        let request = URLRequest(url: url)
        webView.load(request)
    }
}

// Step 2: Integrate WebView into SurveillanceView
struct SurveillanceView: View {
    private let streamURL = URL(string:"https://www.youtube.com/watch?v=RN_ZgV0Lk-Y" )! // Replace with your server URL
    
    var body: some View {
        VStack {
            Text("Surveillance Feed")
                .font(.largeTitle)
                .padding()
            
            WebView(url: streamURL) // Embed the video stream here
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .navigationBarTitle("Surveillance", displayMode: .inline)
    }
}

struct SurveillanceView_Previews: PreviewProvider {
    static var previews: some View {
        SurveillanceView()
    }
}

