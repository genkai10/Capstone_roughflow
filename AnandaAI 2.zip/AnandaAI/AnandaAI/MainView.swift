import SwiftUI

struct MainView: View {
    var body: some View {
        NavigationView {
            VStack(spacing: 30) {
                Spacer()
                
                Text("Ananda AI")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.blue)
                
                NavigationLink(destination: SurveillanceView()) {
                    Text("View Surveillance")
                        .font(.title2)
                        .foregroundColor(.white)
                        .padding()
                        .frame(width: 250)
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                
                NavigationLink(destination: AlertsView()) {
                    Text("Alerts")
                        .font(.title2)
                        .foregroundColor(.white)
                        .padding()
                        .frame(width: 250)
                        .background(Color.red)
                        .cornerRadius(10)
                }
                NavigationLink(destination: WatchDataView()) { // New Button
                                    Text("Apple Watch Data")
                                        .font(.title2)
                                        .foregroundColor(.white)
                                        .padding()
                                        .frame(width: 250)
                                        .background(Color.orange)
                                        .cornerRadius(10)
                                }
                
                NavigationLink(destination: AccelerometerView()) {
                    Text("View Accelerometer Details")
                        .font(.title2)
                        .foregroundColor(.white)
                        .padding()
                        .frame(width: 250)
                        .background(Color.green)
                        .cornerRadius(10)
                }
                
                NavigationLink(destination: ProfileView()) {
                    Text("Profile")
                        .font(.title2)
                        .foregroundColor(.white)
                        .padding()
                        .frame(width: 250)
                        .background(Color.purple)
                        .cornerRadius(10)
                }
                
                Spacer()
            }
            .navigationTitle("Home")
            .padding()
        }
    }
}

struct HomePageView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}
