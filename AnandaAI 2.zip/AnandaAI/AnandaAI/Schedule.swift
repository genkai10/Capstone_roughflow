//
//  Schedule.swift
//  AnandaAI
//
//  Created by Diya Maria on 26/09/24.
//

struct Schedule: Codable, Identifiable {
    let id: Int
    let patientName: String
    let medicineName: String
    let timing: String
    let quantity: Int
}

