//
//  HealthDataManager.swift
//  AnandaAI
//
//  Created by Dharini Mrug on 02/11/24.
//
import Foundation
import HealthKit

class HealthDataManager: ObservableObject {
    private var healthStore = HKHealthStore()
    @Published var heartRate: Double?

    init() {
        requestAuthorization()
    }
    
    private func requestAuthorization() {
        // Define the types of data we want to read
        let heartRateType = HKObjectType.quantityType(forIdentifier: .heartRate)!
        
        // Request permission from the user to read the heart rate data
        healthStore.requestAuthorization(toShare: [], read: [heartRateType]) { success, error in
            if !success {
                print("Authorization failed with error: \(String(describing: error))")
            } else {
                print("Authorization successful")
                // Start reading data after authorization
                self.startHeartRateUpdates()
            }
        }
    }
    func startHeartRateUpdates() {
        guard let heartRateType = HKObjectType.quantityType(forIdentifier: .heartRate) else { return }
        let query = HKAnchoredObjectQuery(type: heartRateType, predicate: nil, anchor: nil, limit: HKObjectQueryNoLimit) { query, samples, deletedObjects, anchor, error in
            if let heartRateSample = samples?.last as? HKQuantitySample {
                DispatchQueue.main.async {
                    self.heartRate = heartRateSample.quantity.doubleValue(for: HKUnit(from: "count/min"))
                }
            }
        }
        healthStore.execute(query)
    }
}
