//
//  WatchDataView.swift
//  AnandaAI
//
//  Created by Dharini Mrug on 02/11/24.
//

import Foundation
import SwiftUI
import WatchConnectivity
struct WatchDataView: View {
    @StateObject private var healthDataManager = HealthDataManager()
    @StateObject private var motionDataManager = MotionDataManager()

    var body: some View {
        VStack(spacing: 20) {
            Text("Apple Watch Data")
                .font(.largeTitle)
                .padding()
            
            if let heartRate = healthDataManager.heartRate {
                Text("Heart Rate: \(heartRate, specifier: "%.1f") BPM")
                    .font(.title2)
            } else {
                Text("Heart Rate: Loading...")
                    .font(.title2)
            }

            if let accelData = motionDataManager.accelerometerData {
                Text("Accelerometer Data:")
                    .font(.title2)
                Text("X: \(accelData.acceleration.x, specifier: "%.2f")")
                Text("Y: \(accelData.acceleration.y, specifier: "%.2f")")
                Text("Z: \(accelData.acceleration.z, specifier: "%.2f")")
            } else {
                Text("Accelerometer Data: Loading...")
                    .font(.title2)
            }
            
            Button("Start Heart Rate Monitoring") {
                healthDataManager.startHeartRateUpdates()
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
            
            Button("Start Accelerometer Monitoring") {
                motionDataManager.startAccelerometerUpdates()
            }
            .padding()
            .background(Color.green)
            .foregroundColor(.white)
            .cornerRadius(10)
            
            Spacer()
        }
        .padding()
    }
}

struct WatchDataView_Previews: PreviewProvider {
    static var previews: some View {
        WatchDataView()
    }
}
class WatchSessionDelegate: NSObject, WCSessionDelegate {
    
    var dataHandler: ((Data) -> Void)?
    
    init(dataHandler: @escaping (Data) -> Void) {
        self.dataHandler = dataHandler
    }
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        if let error = error {
            print("WCSession activation failed with error: \(error.localizedDescription)")
        } else {
            print("WCSession activated with state: \(activationState.rawValue)")
        }
    }
    
    func sessionDidBecomeInactive(_ session: WCSession) {
        print("WCSession became inactive")
    }

    func sessionDidDeactivate(_ session: WCSession) {
        print("WCSession deactivated")
        WCSession.default.activate()
    }

    func session(_ session: WCSession, didReceiveMessageData messageData: Data) {
        dataHandler?(messageData)
    }
}
